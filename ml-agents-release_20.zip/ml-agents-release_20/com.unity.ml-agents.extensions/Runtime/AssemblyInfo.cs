using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.ML-Agents.Extensions.EditorTests")]
[assembly: InternalsVisibleTo("Unity.ML-Agents.Extensions.Editor")]
[assembly: InternalsVisibleTo("Unity.ML-Agents.Extensions.Tests")]
