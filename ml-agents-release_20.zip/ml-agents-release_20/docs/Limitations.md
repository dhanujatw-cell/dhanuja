# Limitations

See the package-specific Limitations pages:

- [`com.unity.mlagents` Unity package](https://docs.unity3d.com/Packages/com.unity.ml-agents@2.1/manual/index.html#known-limitations)
- [`mlagents` Python package](ML-Agents-README.md)
- [`mlagents_envs` Python package](../ml-agents-envs/README.md#limitations)
