from itertools import product

# Define options
theta_options = ['INC', 'DEC', 'DN']

# Generate combinations
all_combinations = list(product(theta_options, repeat=3))

# Create the dictionary
likedic_action_index = {
    i: f"THETA1_{t1}_THETA2_{t2}_THETA3_{t3}"
    for i, (t1, t2, t3) in enumerate(all_combinations)
}

print(likedic_action_index)


#from itertools import product
#
## Define options
#theta_options = ['INC', 'DEC', 'DN']
#
## Generate combinations
#all_combinations = list(product(theta_options, repeat=1))
#
## Create the dictionary
#likedic_action_index = {
#    i: f"THETA1_{t1}"
#    for i, (t1) in enumerate(all_combinations)
#}
#
#print(likedic_action_index)